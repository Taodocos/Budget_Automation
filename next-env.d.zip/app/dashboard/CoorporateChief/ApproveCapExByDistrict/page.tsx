"use client";

import { useState, useEffect } from "react";
import { ChevronLeftIcon, ChevronRightIcon } from "@heroicons/react/16/solid";
import { fetchSourcesById } from "@/app/service/apiFetchCapitalExpenditureByDistrict";
import apiServices from "@/app/ExportApi";


interface GridRow {
    itemCode: string;      
    Deptdisc: string;    
    item: string;           
    quantity: string;       
    unitPrice: string;     
    totalBudget: string;    
    quarter: string;        
    new: string;            
    replacement: string;    
}


const ExpenditureByDiGrid = () => {
    const [branchCode, setBranchCode] = useState<string | null>(null);
    const [districtRight, setDistrictRight] = useState<string | null>(null);
    const [userId, setUserId] = useState<string | null>(null);
    const [gridData, setGridData] = useState<GridRow[]>([]); 
    const [searchQuery, setSearchQuery] = useState<string>("");
    const [currentPage, setCurrentPage] = useState<number>(0);
    const rowsPerPage = 7;

    const [isHr, setIsHr] = useState<boolean>(false);
    const [isCoo, setIsCoo] = useState<boolean>(false);
    const [isDis, setIsDis] = useState<boolean>(false);
    const [isBus, setIsBus] = useState<boolean>(false);
    const [isBan, setIsBan] = useState<boolean>(false);
    const [isDig, setIsDig] = useState<boolean>(false);
    const [isStr, setIsStr] = useState<boolean>(false);
  
    useEffect(() => {
        const storedBranchCode = sessionStorage.getItem("branch_code");
        const storedDistrictRight = sessionStorage.getItem("district_code");
        const storedUserId = sessionStorage.getItem("userId");
        setBranchCode(storedBranchCode);
        setDistrictRight(storedDistrictRight);
        setUserId(storedUserId); 
    }, []);

    useEffect(() => {
        setIsHr(Number(sessionStorage.getItem("IsHr")) === 1);
        setIsCoo(Number(sessionStorage.getItem("IsCoo")) === 1);
        setIsDis(Number(sessionStorage.getItem("IsDis")) === 1);
        setIsBus(Number(sessionStorage.getItem("IsBus")) === 1);
        setIsBan(Number(sessionStorage.getItem("IsBan")) === 1);
        setIsDig(Number(sessionStorage.getItem("IsDig")) === 1);
        setIsStr(Number(sessionStorage.getItem("IsStr")) === 1);
    }, []);

    useEffect(() => {
        const fetchExpenseData = async () => {
            try {
                const data = await fetchSourcesById(); // Call the new API to fetch data
                console.log("Fetched Data:", data);
                if (data && data.length > 0) {
                    setGridData(data);
                } else {
                    console.log("No data returned.");
                    setGridData([]);
                }
            } catch (err) {
                console.error("Error fetching grid data:", err);
            }
        };
        fetchExpenseData();
    }, []); // Fetch data on component mount

    const determineByWhom = () => {
        if (isHr) return 1;
        if (isDis) return 2;
        if (isCoo) return 3;
        if (isBus) return 4;
        if (isBan) return 5;
        if (isDig) return 6;
        if (isStr) return 7;
        return 0; // Default value if none match
    };

    const handleApprove = async () => {
        if (branchCode && districtRight && userId) {
            const byWhom = determineByWhom();
            const payload = { branch_code: branchCode, district_code: districtRight, UserId: userId, byWhom };
            console.log("Payload to be sent on approve:", JSON.stringify(payload, null, 2)); // Log the payload
            try {
                await apiServices.post('/approve', payload);
                alert("Approved successfully!");
            } catch (error) {
                console.error("Error approving:", error);
            }
        } else {
            alert("Branch code, district code, or user ID is missing.");
        }
    };
    
    const handleReject = async () => {
        if (branchCode && districtRight) {
            const byWhom = determineByWhom();
            const payload = { branch_code: branchCode, district_code: districtRight, byWhom };
            console.log("Payload to be sent on reject:", JSON.stringify(payload, null, 2)); // Log the payload
            try {
                await apiServices.post('/reject', payload);
                alert("Rejected successfully!");
            } catch (error) {
                console.error("Error rejecting:", error);
            }
        } else {
            alert("Branch code or district code is missing.");
        }
    };

    const filteredData = gridData.filter(row =>
        row.Deptdisc && row.Deptdisc.toLowerCase().includes(searchQuery.toLowerCase())
    );

    const totalPages = Math.ceil(filteredData.length / rowsPerPage);
    const currentRows = filteredData.slice(currentPage * rowsPerPage, (currentPage + 1) * rowsPerPage);

    const handleNextPage = () => {
        if (currentPage < totalPages - 1) {
            setCurrentPage(currentPage + 1);
        }
    };

    const handlePreviousPage = () => {
        if (currentPage > 0) {
            setCurrentPage(currentPage - 1);
        }
    };

    return (
        <div className="p-6 bg-gray-100 overflow-hidden">
            <h1 className="mb-4 p-2 border rounded text-black font-bold">Capital Expenditure</h1>
            <input
                type="text"
                placeholder="Search..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="mb-4 p-2 border rounded text-black font-bold"
            />
           
            <div className="bg-white shadow-md rounded p-4">
                <table className="w-full table-auto border-collapse border border-gray-300">
                    <thead>
                        <tr className="bg-[#025AA2] text-left text-sm font-semibold text-[#fedc61]">
                            <th className="border p-2">District</th>
                            <th className="border p-2">Item</th>
                            <th className="border p-2">Quantity</th>
                            <th className="border p-2">Unit Price</th>
                            <th className="border p-2">Total Budget</th>
                            <th className="border p-2">Quarter</th>
                            <th className="border p-2">New</th>
                            <th className="border p-2">Replacement</th>
                        </tr>
                    </thead>
                    <tbody>
                        {currentRows.map((row, index) => (
                            <tr key={`${row.itemCode}-${index}`} className="text-sm text-gray-700">
                                <td className="border p-2">{row.Deptdisc}</td>
                                <td className="border p-2">{row.item}</td>
                                <td className="border p-2">{row.quantity}</td>
                                <td className="border p-2">{row.unitPrice}</td>
                                <td className="border p-2">{row.totalBudget}</td>
                                <td className="border p-2">{row.quarter}</td>
                                <td className="border p-2">{row.new}</td>
                                <td className="border p-2">{row.replacement}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                <div className="flex justify-between mt-4">
                    <button
                        onClick={handlePreviousPage} 
                        disabled={currentPage === 0}
                        className="bg-[#025AA2] text-[#fedc61] p-2 rounded flex items-center"
                    >
                        <ChevronLeftIcon className="h-5 w-5 mr-2" />
                        Previous
                    </button>
                    <button 
                        onClick={handleNextPage} 
                        disabled={currentPage >= totalPages - 1}
                        className="bg-[#025AA2] text-[#fedc61] p-2 rounded flex items-center"
                    >
                        <ChevronRightIcon className="h-5 w-5 mr-2" />
                        Next
                    </button>
                </div>
                <div className="flex justify-center mb-4">
                    <button
                        onClick={handleApprove}
                        className="bg-green-500 text-white p-1 rounded mr-4 transition duration-200 ease-in-out hover:bg-green-700"
                    >
                        Approve
                    </button>
                    <button
                        onClick={handleReject}
                        className="bg-red-500 text-white p-1 rounded transition duration-200 ease-in-out hover:bg-red-700"
                    >
                        Reject
                    </button>
                </div>
            </div>
        </div>
    );
};

export default ExpenditureByDiGrid;