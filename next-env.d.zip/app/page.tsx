//import Image from "next/image";
import Login from "./dashboard/Login/page";

export default function Home() {
  return (
    <div>

<Login/>
    </div>
  
  );
}
