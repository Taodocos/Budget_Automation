import axios from "axios";

const apiServices = axios.create({
    baseURL: "http://172.16.239.24:5292/Bplan_api/app/",
   withCredentials:true,
   headers: {
    "Content-Type": "application/json", // Example header
    
}

});

export default apiServices;