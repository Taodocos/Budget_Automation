import apiServices from '../ExportApi';

// Define the structure of the report form data
export interface ReportFormData {
    id: string;
    estimated: string;
    actual: string;
    netincrement: string;
    projected: string;
    branch_code: string;
    district_code: string;
    parentcode: string; 
    status: string;
    description: string;
    jul: string;  
    aug: string;
    sep: string;
    oct: string;
    nov: string;
    dec: string;
    jan: string;
    feb: string;
    mar: string;
    apr: string;
    may: string;
    jun: string;
}

// Define the expected response structure from the API
interface ApiResponse {
    data: ReportFormData[];
}

// Updated function to include status
export const fetchDataBackend = async (
    branchCode: string,
    districtCode: string,
    status?: string // Optional status parameter
): Promise<ReportFormData[]> => {
    try {
        const payload = {
            branch_code: branchCode,
            district_code: districtCode.split(','),
            status: status // Include status in the payload
        };
        console.log("Payload being sent to backend:", JSON.stringify(payload, null, 2));

        const response = await apiServices.post<ApiResponse>('/getformats_by_branch', payload);
        console.log("Original API Response:", response.data);

        // Check if the response contains data and map it
        if (response.data?.data) { 
            const rowsWithId = response.data.data.map((row, index) => {
                const uniqueId = `${row.branch_code}-${row.parentcode}-${index}`;
                console.log("Generated Unique ID:", uniqueId);
                return {
                    ...row,
                    id: uniqueId,
                    parentcode: row.parentcode
                };
            });
            return rowsWithId as ReportFormData[];
        } else {
            console.log("No data returned for the given branch code.");
            return []; 
        }
    } catch (err) {
        console.error('Error fetching data:', err);
        throw new Error('Failed to fetch data from the backend'); // Throw a more descriptive error
    }
};