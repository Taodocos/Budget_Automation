/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "app/api/login/route";
exports.ids = ["app/api/login/route"];
exports.modules = {

/***/ "next/dist/compiled/next-server/app-page.runtime.dev.js":
/*!*************************************************************************!*\
  !*** external "next/dist/compiled/next-server/app-page.runtime.dev.js" ***!
  \*************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-page.runtime.dev.js");

/***/ }),

/***/ "next/dist/compiled/next-server/app-route.runtime.dev.js":
/*!**************************************************************************!*\
  !*** external "next/dist/compiled/next-server/app-route.runtime.dev.js" ***!
  \**************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-route.runtime.dev.js");

/***/ }),

/***/ "../app-render/after-task-async-storage.external":
/*!***********************************************************************************!*\
  !*** external "next/dist/server/app-render/after-task-async-storage.external.js" ***!
  \***********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/after-task-async-storage.external.js");

/***/ }),

/***/ "../app-render/work-async-storage.external":
/*!*****************************************************************************!*\
  !*** external "next/dist/server/app-render/work-async-storage.external.js" ***!
  \*****************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-async-storage.external.js");

/***/ }),

/***/ "./work-unit-async-storage.external":
/*!**********************************************************************************!*\
  !*** external "next/dist/server/app-render/work-unit-async-storage.external.js" ***!
  \**********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-unit-async-storage.external.js");

/***/ }),

/***/ "assert":
/*!*************************!*\
  !*** external "assert" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ "events":
/*!*************************!*\
  !*** external "events" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ "fs":
/*!*********************!*\
  !*** external "fs" ***!
  \*********************/
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ "http":
/*!***********************!*\
  !*** external "http" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ "https":
/*!************************!*\
  !*** external "https" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ "os":
/*!*********************!*\
  !*** external "os" ***!
  \*********************/
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ "path":
/*!***********************!*\
  !*** external "path" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ "stream":
/*!*************************!*\
  !*** external "stream" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ "tty":
/*!**********************!*\
  !*** external "tty" ***!
  \**********************/
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ "url":
/*!**********************!*\
  !*** external "url" ***!
  \**********************/
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ "util":
/*!***********************!*\
  !*** external "util" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ "zlib":
/*!***********************!*\
  !*** external "zlib" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ "(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?name=app%2Fapi%2Flogin%2Froute&page=%2Fapi%2Flogin%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Flogin%2Froute.ts&appDir=D%3A%5CABa%5CProjects%5CBudgetAutomation%5Cmy-nextjs-app%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=D%3A%5CABa%5CProjects%5CBudgetAutomation%5Cmy-nextjs-app&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?name=app%2Fapi%2Flogin%2Froute&page=%2Fapi%2Flogin%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Flogin%2Froute.ts&appDir=D%3A%5CABa%5CProjects%5CBudgetAutomation%5Cmy-nextjs-app%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=D%3A%5CABa%5CProjects%5CBudgetAutomation%5Cmy-nextjs-app&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D! ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   patchFetch: () => (/* binding */ patchFetch),\n/* harmony export */   routeModule: () => (/* binding */ routeModule),\n/* harmony export */   serverHooks: () => (/* binding */ serverHooks),\n/* harmony export */   workAsyncStorage: () => (/* binding */ workAsyncStorage),\n/* harmony export */   workUnitAsyncStorage: () => (/* binding */ workUnitAsyncStorage)\n/* harmony export */ });\n/* harmony import */ var next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/server/route-modules/app-route/module.compiled */ \"(rsc)/./node_modules/next/dist/server/route-modules/app-route/module.compiled.js\");\n/* harmony import */ var next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/dist/server/route-kind */ \"(rsc)/./node_modules/next/dist/server/route-kind.js\");\n/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/dist/server/lib/patch-fetch */ \"(rsc)/./node_modules/next/dist/server/lib/patch-fetch.js\");\n/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var D_ABa_Projects_BudgetAutomation_my_nextjs_app_app_api_login_route_ts__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app/api/login/route.ts */ \"(rsc)/./app/api/login/route.ts\");\n\n\n\n\n// We inject the nextConfigOutput here so that we can use them in the route\n// module.\nconst nextConfigOutput = \"\"\nconst routeModule = new next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__.AppRouteRouteModule({\n    definition: {\n        kind: next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_ROUTE,\n        page: \"/api/login/route\",\n        pathname: \"/api/login\",\n        filename: \"route\",\n        bundlePath: \"app/api/login/route\"\n    },\n    resolvedPagePath: \"D:\\\\ABa\\\\Projects\\\\BudgetAutomation\\\\my-nextjs-app\\\\app\\\\api\\\\login\\\\route.ts\",\n    nextConfigOutput,\n    userland: D_ABa_Projects_BudgetAutomation_my_nextjs_app_app_api_login_route_ts__WEBPACK_IMPORTED_MODULE_3__\n});\n// Pull out the exports that we need to expose from the module. This should\n// be eliminated when we've moved the other routes to the new format. These\n// are used to hook into the route.\nconst { workAsyncStorage, workUnitAsyncStorage, serverHooks } = routeModule;\nfunction patchFetch() {\n    return (0,next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__.patchFetch)({\n        workAsyncStorage,\n        workUnitAsyncStorage\n    });\n}\n\n\n//# sourceMappingURL=app-route.js.map//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2J1aWxkL3dlYnBhY2svbG9hZGVycy9uZXh0LWFwcC1sb2FkZXIvaW5kZXguanM/bmFtZT1hcHAlMkZhcGklMkZsb2dpbiUyRnJvdXRlJnBhZ2U9JTJGYXBpJTJGbG9naW4lMkZyb3V0ZSZhcHBQYXRocz0mcGFnZVBhdGg9cHJpdmF0ZS1uZXh0LWFwcC1kaXIlMkZhcGklMkZsb2dpbiUyRnJvdXRlLnRzJmFwcERpcj1EJTNBJTVDQUJhJTVDUHJvamVjdHMlNUNCdWRnZXRBdXRvbWF0aW9uJTVDbXktbmV4dGpzLWFwcCU1Q2FwcCZwYWdlRXh0ZW5zaW9ucz10c3gmcGFnZUV4dGVuc2lvbnM9dHMmcGFnZUV4dGVuc2lvbnM9anN4JnBhZ2VFeHRlbnNpb25zPWpzJnJvb3REaXI9RCUzQSU1Q0FCYSU1Q1Byb2plY3RzJTVDQnVkZ2V0QXV0b21hdGlvbiU1Q215LW5leHRqcy1hcHAmaXNEZXY9dHJ1ZSZ0c2NvbmZpZ1BhdGg9dHNjb25maWcuanNvbiZiYXNlUGF0aD0mYXNzZXRQcmVmaXg9Jm5leHRDb25maWdPdXRwdXQ9JnByZWZlcnJlZFJlZ2lvbj0mbWlkZGxld2FyZUNvbmZpZz1lMzAlM0QhIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7O0FBQStGO0FBQ3ZDO0FBQ3FCO0FBQzZCO0FBQzFHO0FBQ0E7QUFDQTtBQUNBLHdCQUF3Qix5R0FBbUI7QUFDM0M7QUFDQSxjQUFjLGtFQUFTO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQSxZQUFZO0FBQ1osQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBLFFBQVEsc0RBQXNEO0FBQzlEO0FBQ0EsV0FBVyw0RUFBVztBQUN0QjtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQzBGOztBQUUxRiIsInNvdXJjZXMiOlsiIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEFwcFJvdXRlUm91dGVNb2R1bGUgfSBmcm9tIFwibmV4dC9kaXN0L3NlcnZlci9yb3V0ZS1tb2R1bGVzL2FwcC1yb3V0ZS9tb2R1bGUuY29tcGlsZWRcIjtcbmltcG9ydCB7IFJvdXRlS2luZCB9IGZyb20gXCJuZXh0L2Rpc3Qvc2VydmVyL3JvdXRlLWtpbmRcIjtcbmltcG9ydCB7IHBhdGNoRmV0Y2ggYXMgX3BhdGNoRmV0Y2ggfSBmcm9tIFwibmV4dC9kaXN0L3NlcnZlci9saWIvcGF0Y2gtZmV0Y2hcIjtcbmltcG9ydCAqIGFzIHVzZXJsYW5kIGZyb20gXCJEOlxcXFxBQmFcXFxcUHJvamVjdHNcXFxcQnVkZ2V0QXV0b21hdGlvblxcXFxteS1uZXh0anMtYXBwXFxcXGFwcFxcXFxhcGlcXFxcbG9naW5cXFxccm91dGUudHNcIjtcbi8vIFdlIGluamVjdCB0aGUgbmV4dENvbmZpZ091dHB1dCBoZXJlIHNvIHRoYXQgd2UgY2FuIHVzZSB0aGVtIGluIHRoZSByb3V0ZVxuLy8gbW9kdWxlLlxuY29uc3QgbmV4dENvbmZpZ091dHB1dCA9IFwiXCJcbmNvbnN0IHJvdXRlTW9kdWxlID0gbmV3IEFwcFJvdXRlUm91dGVNb2R1bGUoe1xuICAgIGRlZmluaXRpb246IHtcbiAgICAgICAga2luZDogUm91dGVLaW5kLkFQUF9ST1VURSxcbiAgICAgICAgcGFnZTogXCIvYXBpL2xvZ2luL3JvdXRlXCIsXG4gICAgICAgIHBhdGhuYW1lOiBcIi9hcGkvbG9naW5cIixcbiAgICAgICAgZmlsZW5hbWU6IFwicm91dGVcIixcbiAgICAgICAgYnVuZGxlUGF0aDogXCJhcHAvYXBpL2xvZ2luL3JvdXRlXCJcbiAgICB9LFxuICAgIHJlc29sdmVkUGFnZVBhdGg6IFwiRDpcXFxcQUJhXFxcXFByb2plY3RzXFxcXEJ1ZGdldEF1dG9tYXRpb25cXFxcbXktbmV4dGpzLWFwcFxcXFxhcHBcXFxcYXBpXFxcXGxvZ2luXFxcXHJvdXRlLnRzXCIsXG4gICAgbmV4dENvbmZpZ091dHB1dCxcbiAgICB1c2VybGFuZFxufSk7XG4vLyBQdWxsIG91dCB0aGUgZXhwb3J0cyB0aGF0IHdlIG5lZWQgdG8gZXhwb3NlIGZyb20gdGhlIG1vZHVsZS4gVGhpcyBzaG91bGRcbi8vIGJlIGVsaW1pbmF0ZWQgd2hlbiB3ZSd2ZSBtb3ZlZCB0aGUgb3RoZXIgcm91dGVzIHRvIHRoZSBuZXcgZm9ybWF0LiBUaGVzZVxuLy8gYXJlIHVzZWQgdG8gaG9vayBpbnRvIHRoZSByb3V0ZS5cbmNvbnN0IHsgd29ya0FzeW5jU3RvcmFnZSwgd29ya1VuaXRBc3luY1N0b3JhZ2UsIHNlcnZlckhvb2tzIH0gPSByb3V0ZU1vZHVsZTtcbmZ1bmN0aW9uIHBhdGNoRmV0Y2goKSB7XG4gICAgcmV0dXJuIF9wYXRjaEZldGNoKHtcbiAgICAgICAgd29ya0FzeW5jU3RvcmFnZSxcbiAgICAgICAgd29ya1VuaXRBc3luY1N0b3JhZ2VcbiAgICB9KTtcbn1cbmV4cG9ydCB7IHJvdXRlTW9kdWxlLCB3b3JrQXN5bmNTdG9yYWdlLCB3b3JrVW5pdEFzeW5jU3RvcmFnZSwgc2VydmVySG9va3MsIHBhdGNoRmV0Y2gsICB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1hcHAtcm91dGUuanMubWFwIl0sIm5hbWVzIjpbXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?name=app%2Fapi%2Flogin%2Froute&page=%2Fapi%2Flogin%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Flogin%2Froute.ts&appDir=D%3A%5CABa%5CProjects%5CBudgetAutomation%5Cmy-nextjs-app%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=D%3A%5CABa%5CProjects%5CBudgetAutomation%5Cmy-nextjs-app&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!\n");

/***/ }),

/***/ "(rsc)/./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?server=true!":
/*!******************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?server=true! ***!
  \******************************************************************************************************/
/***/ (() => {



/***/ }),

/***/ "(ssr)/./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?server=true!":
/*!******************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?server=true! ***!
  \******************************************************************************************************/
/***/ (() => {



/***/ }),

/***/ "(rsc)/./app/ExportAdminAPI.ts":
/*!*******************************!*\
  !*** ./app/ExportAdminAPI.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! axios */ \"(rsc)/./node_modules/axios/lib/axios.js\");\n\nconst AdminapiServices = axios__WEBPACK_IMPORTED_MODULE_0__[\"default\"].create({\n    baseURL: 'http://172.16.239.161:8081/api',\n    headers: {\n        'Content-Type': 'application/json'\n    }\n});\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AdminapiServices);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9hcHAvRXhwb3J0QWRtaW5BUEkudHMiLCJtYXBwaW5ncyI6Ijs7Ozs7QUFBMEI7QUFFMUIsTUFBTUMsbUJBQW1CRCw2Q0FBS0EsQ0FBQ0UsTUFBTSxDQUFDO0lBQ2xDQyxTQUFTO0lBQ1RDLFNBQVM7UUFDTCxnQkFBZ0I7SUFDcEI7QUFDSjtBQUVBLGlFQUFlSCxnQkFBZ0JBLEVBQUMiLCJzb3VyY2VzIjpbIkQ6XFxBQmFcXFByb2plY3RzXFxCdWRnZXRBdXRvbWF0aW9uXFxteS1uZXh0anMtYXBwXFxhcHBcXEV4cG9ydEFkbWluQVBJLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBheGlvcyBmcm9tICdheGlvcyc7XHJcblxyXG5jb25zdCBBZG1pbmFwaVNlcnZpY2VzID0gYXhpb3MuY3JlYXRlKHtcclxuICAgIGJhc2VVUkw6ICdodHRwOi8vMTcyLjE2LjIzOS4xNjE6ODA4MS9hcGknLCAvLyBBZGp1c3QgdGhpcyB0byB5b3VyIEFTUC5ORVQgQVBJIGJhc2UgVVJMXHJcbiAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyxcclxuICAgIH0sXHJcbn0pO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgQWRtaW5hcGlTZXJ2aWNlczsiXSwibmFtZXMiOlsiYXhpb3MiLCJBZG1pbmFwaVNlcnZpY2VzIiwiY3JlYXRlIiwiYmFzZVVSTCIsImhlYWRlcnMiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(rsc)/./app/ExportAdminAPI.ts\n");

/***/ }),

/***/ "(rsc)/./app/api/login/route.ts":
/*!********************************!*\
  !*** ./app/api/login/route.ts ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   GET: () => (/* binding */ GET),\n/* harmony export */   POST: () => (/* binding */ POST)\n/* harmony export */ });\n/* harmony import */ var next_server__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/server */ \"(rsc)/./node_modules/next/dist/api/server.js\");\n/* harmony import */ var _app_ExportAdminAPI__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/app/ExportAdminAPI */ \"(rsc)/./app/ExportAdminAPI.ts\");\n// app/api/login/route.ts\n\n//import axios from 'axios';\n\nasync function POST(request) {\n    try {\n        const body = await request.json(); // Parse the JSON body\n        const { username, password } = body;\n        console.log(\"Login attempt:\", {\n            username,\n            password\n        });\n        // Send login request to the ASP.NET API\n        const apiResponse = await _app_ExportAdminAPI__WEBPACK_IMPORTED_MODULE_1__[\"default\"].post('/auth/login', {\n            username,\n            password\n        });\n        if (apiResponse.data.success) {\n            return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({\n                message: \"Login successful!\",\n                userId: apiResponse.data.userId,\n                branch_code: apiResponse.data.branch_code,\n                branch_name: apiResponse.data.branch_name,\n                region: apiResponse.data.region,\n                district_code: apiResponse.data.district_code,\n                IsHr: apiResponse.data.IsHr,\n                IsCoo: apiResponse.data.IsCoo,\n                IsDis: apiResponse.data.IsDis,\n                IsBus: apiResponse.data.IsBus,\n                IsBan: apiResponse.data.IsBan,\n                IsDig: apiResponse.data.IsDig,\n                IsStr: apiResponse.data.IsStr\n            }, {\n                status: 200\n            });\n        } else {\n            return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({\n                message: apiResponse.data.message || \"Invalid credentials\"\n            }, {\n                status: 401\n            });\n        }\n    } catch (error) {\n        console.error(\"Error handling request:\", error);\n        return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({\n            message: \"Failed to process request\"\n        }, {\n            status: 500\n        });\n    }\n}\nasync function GET() {\n    return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({\n        message: \"GET method not allowed for this route\"\n    }, {\n        status: 405\n    });\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9hcHAvYXBpL2xvZ2luL3JvdXRlLnRzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFBQSx5QkFBeUI7QUFDa0I7QUFDM0MsNEJBQTRCO0FBQ3dCO0FBRTdDLGVBQWVFLEtBQUtDLE9BQWdCO0lBQ3ZDLElBQUk7UUFDQSxNQUFNQyxPQUFPLE1BQU1ELFFBQVFFLElBQUksSUFBSSxzQkFBc0I7UUFDekQsTUFBTSxFQUFFQyxRQUFRLEVBQUVDLFFBQVEsRUFBRSxHQUFHSDtRQUUvQkksUUFBUUMsR0FBRyxDQUFDLGtCQUFrQjtZQUFFSDtZQUFVQztRQUFTO1FBRW5ELHdDQUF3QztRQUN4QyxNQUFNRyxjQUFjLE1BQU1ULDJEQUFnQkEsQ0FBQ1UsSUFBSSxDQUFDLGVBQWU7WUFBRUw7WUFBVUM7UUFBUztRQUdwRixJQUFJRyxZQUFZRSxJQUFJLENBQUNDLE9BQU8sRUFBRTtZQUMxQixPQUFPYixxREFBWUEsQ0FBQ0ssSUFBSSxDQUFDO2dCQUFFUyxTQUFTO2dCQUVoQ0MsUUFBUUwsWUFBWUUsSUFBSSxDQUFDRyxNQUFNO2dCQUMvQkMsYUFBWU4sWUFBWUUsSUFBSSxDQUFDSSxXQUFXO2dCQUN4Q0MsYUFBWVAsWUFBWUUsSUFBSSxDQUFDSyxXQUFXO2dCQUN4Q0MsUUFBT1IsWUFBWUUsSUFBSSxDQUFDTSxNQUFNO2dCQUM5QkMsZUFBY1QsWUFBWUUsSUFBSSxDQUFDTyxhQUFhO2dCQUM1Q0MsTUFBS1YsWUFBWUUsSUFBSSxDQUFDUSxJQUFJO2dCQUMxQkMsT0FBTVgsWUFBWUUsSUFBSSxDQUFDUyxLQUFLO2dCQUM1QkMsT0FBTVosWUFBWUUsSUFBSSxDQUFDVSxLQUFLO2dCQUM1QkMsT0FBTWIsWUFBWUUsSUFBSSxDQUFDVyxLQUFLO2dCQUM1QkMsT0FBTWQsWUFBWUUsSUFBSSxDQUFDWSxLQUFLO2dCQUM1QkMsT0FBTWYsWUFBWUUsSUFBSSxDQUFDYSxLQUFLO2dCQUM1QkMsT0FBTWhCLFlBQVlFLElBQUksQ0FBQ2MsS0FBSztZQUM1QixHQUVHO2dCQUFFQyxRQUFRO1lBQUk7UUFFekIsT0FFSztZQUNELE9BQU8zQixxREFBWUEsQ0FBQ0ssSUFBSSxDQUFDO2dCQUFFUyxTQUFTSixZQUFZRSxJQUFJLENBQUNFLE9BQU8sSUFBSTtZQUFzQixHQUFHO2dCQUFFYSxRQUFRO1lBQUk7UUFDM0c7SUFDSixFQUFFLE9BQU9DLE9BQU87UUFDWnBCLFFBQVFvQixLQUFLLENBQUMsMkJBQTJCQTtRQUN6QyxPQUFPNUIscURBQVlBLENBQUNLLElBQUksQ0FBQztZQUFFUyxTQUFTO1FBQTRCLEdBQUc7WUFBRWEsUUFBUTtRQUFJO0lBQ3JGO0FBQ0o7QUFFTyxlQUFlRTtJQUNsQixPQUFPN0IscURBQVlBLENBQUNLLElBQUksQ0FBQztRQUFFUyxTQUFTO0lBQXdDLEdBQUc7UUFBRWEsUUFBUTtJQUFJO0FBQ2pHIiwic291cmNlcyI6WyJEOlxcQUJhXFxQcm9qZWN0c1xcQnVkZ2V0QXV0b21hdGlvblxcbXktbmV4dGpzLWFwcFxcYXBwXFxhcGlcXGxvZ2luXFxyb3V0ZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBhcHAvYXBpL2xvZ2luL3JvdXRlLnRzXHJcbmltcG9ydCB7IE5leHRSZXNwb25zZSB9IGZyb20gJ25leHQvc2VydmVyJztcclxuLy9pbXBvcnQgYXhpb3MgZnJvbSAnYXhpb3MnO1xyXG5pbXBvcnQgQWRtaW5hcGlTZXJ2aWNlcyBmcm9tICdAL2FwcC9FeHBvcnRBZG1pbkFQSSc7XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gUE9TVChyZXF1ZXN0OiBSZXF1ZXN0KSB7XHJcbiAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IGJvZHkgPSBhd2FpdCByZXF1ZXN0Lmpzb24oKTsgLy8gUGFyc2UgdGhlIEpTT04gYm9keVxyXG4gICAgICAgIGNvbnN0IHsgdXNlcm5hbWUsIHBhc3N3b3JkIH0gPSBib2R5OyBcclxuXHJcbiAgICAgICAgY29uc29sZS5sb2coXCJMb2dpbiBhdHRlbXB0OlwiLCB7IHVzZXJuYW1lLCBwYXNzd29yZCB9KTsgXHJcblxyXG4gICAgICAgIC8vIFNlbmQgbG9naW4gcmVxdWVzdCB0byB0aGUgQVNQLk5FVCBBUElcclxuICAgICAgICBjb25zdCBhcGlSZXNwb25zZSA9IGF3YWl0IEFkbWluYXBpU2VydmljZXMucG9zdCgnL2F1dGgvbG9naW4nLCB7IHVzZXJuYW1lLCBwYXNzd29yZCB9KTtcclxuXHJcbiAgICAgICBcclxuICAgICAgICBpZiAoYXBpUmVzcG9uc2UuZGF0YS5zdWNjZXNzKSB7XHJcbiAgICAgICAgICAgIHJldHVybiBOZXh0UmVzcG9uc2UuanNvbih7IG1lc3NhZ2U6IFwiTG9naW4gc3VjY2Vzc2Z1bCFcIixcclxuXHJcbiAgICAgICAgICAgICAgICB1c2VySWQ6IGFwaVJlc3BvbnNlLmRhdGEudXNlcklkICwgXHJcbiAgICAgICAgICAgICAgICBicmFuY2hfY29kZTphcGlSZXNwb25zZS5kYXRhLmJyYW5jaF9jb2RlLFxyXG4gICAgICAgICAgICAgICAgYnJhbmNoX25hbWU6YXBpUmVzcG9uc2UuZGF0YS5icmFuY2hfbmFtZSxcclxuICAgICAgICAgICAgICAgIHJlZ2lvbjphcGlSZXNwb25zZS5kYXRhLnJlZ2lvbixcclxuICAgICAgICAgICAgICAgIGRpc3RyaWN0X2NvZGU6YXBpUmVzcG9uc2UuZGF0YS5kaXN0cmljdF9jb2RlICwgXHJcbiAgICAgICAgICAgICAgICBJc0hyOmFwaVJlc3BvbnNlLmRhdGEuSXNIciAsIFxyXG4gICAgICAgICAgICAgICAgSXNDb286YXBpUmVzcG9uc2UuZGF0YS5Jc0NvbyxcclxuICAgICAgICAgICAgICAgIElzRGlzOmFwaVJlc3BvbnNlLmRhdGEuSXNEaXMsXHJcbiAgICAgICAgICAgICAgICBJc0J1czphcGlSZXNwb25zZS5kYXRhLklzQnVzLFxyXG4gICAgICAgICAgICAgICAgSXNCYW46YXBpUmVzcG9uc2UuZGF0YS5Jc0JhbixcclxuICAgICAgICAgICAgICAgIElzRGlnOmFwaVJlc3BvbnNlLmRhdGEuSXNEaWcsXHJcbiAgICAgICAgICAgICAgICBJc1N0cjphcGlSZXNwb25zZS5kYXRhLklzU3RyXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgIHsgc3RhdHVzOiAyMDAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICB9IFxyXG4gICAgICAgIFxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICByZXR1cm4gTmV4dFJlc3BvbnNlLmpzb24oeyBtZXNzYWdlOiBhcGlSZXNwb25zZS5kYXRhLm1lc3NhZ2UgfHwgXCJJbnZhbGlkIGNyZWRlbnRpYWxzXCIgfSwgeyBzdGF0dXM6IDQwMSB9KTtcclxuICAgICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBoYW5kbGluZyByZXF1ZXN0OlwiLCBlcnJvcik7XHJcbiAgICAgICAgcmV0dXJuIE5leHRSZXNwb25zZS5qc29uKHsgbWVzc2FnZTogXCJGYWlsZWQgdG8gcHJvY2VzcyByZXF1ZXN0XCIgfSwgeyBzdGF0dXM6IDUwMCB9KTtcclxuICAgIH1cclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIEdFVCgpIHtcclxuICAgIHJldHVybiBOZXh0UmVzcG9uc2UuanNvbih7IG1lc3NhZ2U6IFwiR0VUIG1ldGhvZCBub3QgYWxsb3dlZCBmb3IgdGhpcyByb3V0ZVwiIH0sIHsgc3RhdHVzOiA0MDUgfSk7XHJcbn0iXSwibmFtZXMiOlsiTmV4dFJlc3BvbnNlIiwiQWRtaW5hcGlTZXJ2aWNlcyIsIlBPU1QiLCJyZXF1ZXN0IiwiYm9keSIsImpzb24iLCJ1c2VybmFtZSIsInBhc3N3b3JkIiwiY29uc29sZSIsImxvZyIsImFwaVJlc3BvbnNlIiwicG9zdCIsImRhdGEiLCJzdWNjZXNzIiwibWVzc2FnZSIsInVzZXJJZCIsImJyYW5jaF9jb2RlIiwiYnJhbmNoX25hbWUiLCJyZWdpb24iLCJkaXN0cmljdF9jb2RlIiwiSXNIciIsIklzQ29vIiwiSXNEaXMiLCJJc0J1cyIsIklzQmFuIiwiSXNEaWciLCJJc1N0ciIsInN0YXR1cyIsImVycm9yIiwiR0VUIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(rsc)/./app/api/login/route.ts\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next","vendor-chunks/mime-db","vendor-chunks/axios","vendor-chunks/follow-redirects","vendor-chunks/debug","vendor-chunks/form-data","vendor-chunks/asynckit","vendor-chunks/combined-stream","vendor-chunks/mime-types","vendor-chunks/proxy-from-env","vendor-chunks/ms","vendor-chunks/supports-color","vendor-chunks/delayed-stream","vendor-chunks/has-flag"], () => (__webpack_exec__("(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?name=app%2Fapi%2Flogin%2Froute&page=%2Fapi%2Flogin%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Flogin%2Froute.ts&appDir=D%3A%5CABa%5CProjects%5CBudgetAutomation%5Cmy-nextjs-app%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=D%3A%5CABa%5CProjects%5CBudgetAutomation%5Cmy-nextjs-app&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!")));
module.exports = __webpack_exports__;

})();